#include <LPC210x.H>   

void PM_power_down (void); 
