#include "planificador.h"


//Se encargar� de iniciar la cola 
void planificador_iniciar(){
    /*gpio_hal_pin_dir_t pin = GPIO_OVERFLOW;
    FIFO_inicializar(pin);
    EVENTO_T* Id_Evento;
    uint32_t* auxData;
    while (1)
    {
        if (eventos_sin_tratar() == 1)
        {
            FIFO_extraer(Id_Evento,auxData);
        }
        
    }*/
}
