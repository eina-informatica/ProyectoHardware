#include <stddef.h>
#include "cola.h"
#include "io_reserva.h"
#include "gpio_hal.h"
#include "hello_world.h"
#include "timer_hal.h"
#include "timer_drv.h"

#ifndef PLANIFICADOR_H
#define PLANIFICADOR_H

void planificador(void);

#endif
