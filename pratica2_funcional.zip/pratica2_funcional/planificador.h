#include "cola.h"
#include "io_reserva.h"
#include "gpio_hal.h"
 //Se encargar� de iniciar la cola 
 
void planificador_inicializar(void);
