extern void init_timer0(void);
extern void init_timer1(void);
