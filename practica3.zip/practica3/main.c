#include "planificador.h"

int main (void) {
	planificador();
	while(1);
}

