
#ifndef WD_H
#define WD_H
#include "swi.h"
void WD_hal_init(int sec);
void WD_hal_feed(void);
void WD_hal_test(void);
#endif
