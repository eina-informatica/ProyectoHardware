#include "conecta_K_2023.h"

// MAIN 
int main (void) {
	//inicializar sistema
	//... practica 2
	
	//jugar
	conecta_K_jugar();
	
	while(1); //no hay S.O., no se retorna
}
